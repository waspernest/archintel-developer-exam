export const Access = {

	main: {

		onLoad: async () => {



		}

	}

}

window.Access = Access;